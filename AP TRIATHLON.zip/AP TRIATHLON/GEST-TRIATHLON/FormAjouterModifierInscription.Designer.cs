﻿namespace GEST_TRIATHLON
{
    partial class FormAjouterModifierInscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LabelId = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.chk_Forfait = new System.Windows.Forms.CheckBox();
            this.dtp_DateInscription = new System.Windows.Forms.DateTimePicker();
            this.LabelDateInscription = new System.Windows.Forms.Label();
            this.tb_NumDossard = new System.Windows.Forms.TextBox();
            this.LabelNumDossard = new System.Windows.Forms.Label();
            this.cb_Triathlon = new System.Windows.Forms.ComboBox();
            this.LabelTriathlon = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // LabelId
            // 
            this.LabelId.AutoSize = true;
            this.LabelId.Location = new System.Drawing.Point(12, 33);
            this.LabelId.Name = "LabelId";
            this.LabelId.Size = new System.Drawing.Size(57, 13);
            this.LabelId.TabIndex = 72;
            this.LabelId.Text = "Triathlete :";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(420, 205);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 30);
            this.button1.TabIndex = 89;
            this.button1.Text = "Supprimer";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(130, 205);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 30);
            this.button2.TabIndex = 88;
            this.button2.Text = "Annuler";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(15, 205);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 30);
            this.button3.TabIndex = 87;
            this.button3.Text = "Valider";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // chk_Forfait
            // 
            this.chk_Forfait.AutoSize = true;
            this.chk_Forfait.Location = new System.Drawing.Point(120, 165);
            this.chk_Forfait.Name = "chk_Forfait";
            this.chk_Forfait.Size = new System.Drawing.Size(55, 17);
            this.chk_Forfait.TabIndex = 86;
            this.chk_Forfait.Text = "Forfait";
            this.chk_Forfait.UseVisualStyleBackColor = true;
            // 
            // dtp_DateInscription
            // 
            this.dtp_DateInscription.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_DateInscription.Location = new System.Drawing.Point(120, 127);
            this.dtp_DateInscription.Name = "dtp_DateInscription";
            this.dtp_DateInscription.Size = new System.Drawing.Size(120, 20);
            this.dtp_DateInscription.TabIndex = 85;
            // 
            // LabelDateInscription
            // 
            this.LabelDateInscription.AutoSize = true;
            this.LabelDateInscription.Location = new System.Drawing.Point(12, 130);
            this.LabelDateInscription.Name = "LabelDateInscription";
            this.LabelDateInscription.Size = new System.Drawing.Size(94, 13);
            this.LabelDateInscription.TabIndex = 84;
            this.LabelDateInscription.Text = "Date d\'inscription :";
            // 
            // tb_NumDossard
            // 
            this.tb_NumDossard.Location = new System.Drawing.Point(120, 92);
            this.tb_NumDossard.Name = "tb_NumDossard";
            this.tb_NumDossard.Size = new System.Drawing.Size(100, 20);
            this.tb_NumDossard.TabIndex = 83;
            // 
            // LabelNumDossard
            // 
            this.LabelNumDossard.AutoSize = true;
            this.LabelNumDossard.Location = new System.Drawing.Point(12, 95);
            this.LabelNumDossard.Name = "LabelNumDossard";
            this.LabelNumDossard.Size = new System.Drawing.Size(67, 13);
            this.LabelNumDossard.TabIndex = 82;
            this.LabelNumDossard.Text = "N° Dossard :";
            // 
            // cb_Triathlon
            // 
            this.cb_Triathlon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Triathlon.FormattingEnabled = true;
            this.cb_Triathlon.Location = new System.Drawing.Point(120, 57);
            this.cb_Triathlon.Name = "cb_Triathlon";
            this.cb_Triathlon.Size = new System.Drawing.Size(400, 21);
            this.cb_Triathlon.TabIndex = 81;
            // 
            // LabelTriathlon
            // 
            this.LabelTriathlon.AutoSize = true;
            this.LabelTriathlon.Location = new System.Drawing.Point(12, 60);
            this.LabelTriathlon.Name = "LabelTriathlon";
            this.LabelTriathlon.Size = new System.Drawing.Size(54, 13);
            this.LabelTriathlon.TabIndex = 80;
            this.LabelTriathlon.Text = "Triathlon :";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(120, 30);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(182, 21);
            this.comboBox1.TabIndex = 90;
            // 
            // FormAjouterModifierInscription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 247);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.chk_Forfait);
            this.Controls.Add(this.dtp_DateInscription);
            this.Controls.Add(this.LabelDateInscription);
            this.Controls.Add(this.tb_NumDossard);
            this.Controls.Add(this.LabelNumDossard);
            this.Controls.Add(this.cb_Triathlon);
            this.Controls.Add(this.LabelTriathlon);
            this.Controls.Add(this.LabelId);
            this.Name = "FormAjouterModifierInscription";
            this.Text = "Ajouter ou modifier une Inscription";
            this.Load += new System.EventHandler(this.FormAjouterModifierInscription_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label LabelId;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.CheckBox chk_Forfait;
        private System.Windows.Forms.DateTimePicker dtp_DateInscription;
        private System.Windows.Forms.Label LabelDateInscription;
        private System.Windows.Forms.TextBox tb_NumDossard;
        private System.Windows.Forms.Label LabelNumDossard;
        private System.Windows.Forms.ComboBox cb_Triathlon;
        private System.Windows.Forms.Label LabelTriathlon;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}