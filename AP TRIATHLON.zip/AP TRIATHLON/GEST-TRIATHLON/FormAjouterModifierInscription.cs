﻿using BLL;
using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GEST_TRIATHLON
{
    public partial class FormAjouterModifierInscription : Form
    {
        public FormAjouterModifierInscription()
        {
            InitializeComponent();
            RemplirComboBoxes();

            button1.Click += button1_Click;
            button2.Click += button2_Click;
            button3.Click += button3_Click;

            button1.Visible = false;
        }

        private bool modeAjout = true;
        private Inscription inscriptionActuelle;

        private void FormAjouterModifierInscription_Load(object sender, EventArgs e)
        {

        }

        private void LabelNom_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        public void ModeAjout()
        {
            modeAjout = true;
            this.Text = "Ajouter inscription";

            button1.Visible = false;
        }

        public void ModeModification(Inscription i)
        {
            modeAjout = false;
            inscriptionActuelle = i;

            this.Text = "Modifier inscription";

            button1.Visible = true;

            RemplirComboBoxes();

            cb_Triathlon.SelectedValue = i.IdTriathlon;
            comboBox1.SelectedValue = i.NumLicence;

            tb_NumDossard.Text = i.NumDossard.ToString();
            dtp_DateInscription.Value = i.DateInscription;
            chk_Forfait.Checked = i.Forfait;
        }

        private void button3_Click(object sender, EventArgs e) 
        {
            Inscription i = new Inscription();

            i.IdTriathlon = Convert.ToInt32(cb_Triathlon.SelectedValue);
            i.NumDossard = int.Parse(tb_NumDossard.Text);
            i.DateInscription = dtp_DateInscription.Value;
            i.Forfait = chk_Forfait.Checked;
            i.NumLicence = Convert.ToInt32(comboBox1.SelectedValue);

            InscriptionDAO.AjouterInscription(i);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RemplirComboBoxes()
        {
            var triathlons = TriathlonDAO.GetLesTriathlons();

            cb_Triathlon.DataSource = triathlons;
            cb_Triathlon.DisplayMember = "NomTriathlon";
            cb_Triathlon.ValueMember = "IdTriathlon";
            cb_Triathlon.SelectedIndex = -1;

            var triathletes = TriathleteDAO.GetTousLesTriathletes();

            comboBox1.DataSource = triathletes;
            comboBox1.DisplayMember = "Nom";        
            comboBox1.ValueMember = "NumLicence";
            comboBox1.SelectedIndex = -1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Supprimer cette inscription ?", "Confirmation",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                InscriptionDAO.SupprimerInscription(
                    Convert.ToInt32(cb_Triathlon.SelectedValue),
                    int.Parse(tb_NumDossard.Text)
                );

                MessageBox.Show("Inscription supprimée");

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }
    }
}
