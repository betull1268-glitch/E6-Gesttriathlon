using BLL;
using DAL;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace GEST_TRIATHLON
{
    public partial class FormAjouterModifierTriathlete : Form
    {
        private Triathlete triathlete;
        private bool modeModification;

        public FormAjouterModifierTriathlete()
        {
            InitializeComponent();
            modeModification = false;
            btn_ReinitialiserMdp.Visible = false;
        }

        public FormAjouterModifierTriathlete(Triathlete triathlete) : this()
        {
            this.triathlete = triathlete;
            modeModification = true;
        }

        private void FormMiseAJourTriathlete_Load(object sender, EventArgs e)
        {
            ChargerCategories();

            if (modeModification && triathlete != null)
            {
                RemplirChamps();
                ChargerInscriptions();
                tb_NumLicence.ReadOnly = true;
                tb_Login.ReadOnly = true;
                this.Text = "Modifier un triathl�te";
                btn_Supprimer.Visible = true;
                btn_ReinitialiserMdp.Visible = false;
                dgv_Inscriptions.Visible = true;
                LabelInscriptions.Visible = true;
            }
            else
            {
                this.Text = "Ajouter un triathl�te";
                GenererNouvelNumLicence();
                tb_NumLicence.ReadOnly = true;
                btn_Supprimer.Visible = false;
                btn_ReinitialiserMdp.Visible = false;
                dgv_Inscriptions.Visible = false;
                LabelInscriptions.Visible = false;
                cb_Sexe.Items.Clear();
                cb_Sexe.Items.Add("M");
                cb_Sexe.Items.Add("F");
            }
        }

        private void GenererNouvelNumLicence()
        {
            var triathletes = TriathleteDAO.GetTousLesTriathletes();
            int maxNumLicence = triathletes.Count > 0 ? triathletes.Max(t => t.NumLicence) : 0;
            tb_NumLicence.Text = (maxNumLicence + 1).ToString();
        }

        private void ChargerCategories()
        {
            var categories = CategorieDAO.GetToutesLesCategories();
            cb_Categorie.DataSource = categories;
            cb_Categorie.DisplayMember = "Libelle";
            cb_Categorie.ValueMember = "CodeCategorie";
        }

        private void RemplirChamps()
        {
            tb_NumLicence.Text = triathlete.NumLicence.ToString();
            tb_Login.Text = triathlete.Login;
            tb_Nom.Text = triathlete.Nom;
            tb_Prenom.Text = triathlete.Prenom;
            cb_Sexe.SelectedItem = triathlete.Sexe.ToString();
            tb_AdresseRue.Text = triathlete.AdresseRue;
            tb_AdresseCP.Text = triathlete.AdresseCP;
            tb_AdresseVille.Text = triathlete.AdresseVille;
            dtp_DateNaissance.Value = triathlete.DateNaissance;
            cb_Categorie.SelectedValue = triathlete.CodeCategorie;
        }

        private void ChargerInscriptions()
        {
            var inscriptions = InscriptionDAO.GetInscriptionsParNumLicence(triathlete.NumLicence);
            dgv_Inscriptions.DataSource = inscriptions;

            if (dgv_Inscriptions.Columns["NumLicence"] != null)
                dgv_Inscriptions.Columns["NumLicence"].Visible = false;

            ConfigurerColonnesInscriptions();
        }

        private void ConfigurerColonnesInscriptions()
        {
            if (dgv_Inscriptions.Columns["IdTriathlon"] != null)
                dgv_Inscriptions.Columns["IdTriathlon"].HeaderText = "ID Triathlon";

            if (dgv_Inscriptions.Columns["NumDossard"] != null)
                dgv_Inscriptions.Columns["NumDossard"].HeaderText = "N� Dossard";

            if (dgv_Inscriptions.Columns["DateInscription"] != null)
            {
                dgv_Inscriptions.Columns["DateInscription"].HeaderText = "Date Inscription";
                dgv_Inscriptions.Columns["DateInscription"].DefaultCellStyle.Format = "dd/MM/yyyy";
            }

            if (dgv_Inscriptions.Columns["NomTriathlon"] != null)
                dgv_Inscriptions.Columns["NomTriathlon"].HeaderText = "Nom Triathlon";

            if (dgv_Inscriptions.Columns["DateTriathlon"] != null)
            {
                dgv_Inscriptions.Columns["DateTriathlon"].HeaderText = "Date Triathlon";
                dgv_Inscriptions.Columns["DateTriathlon"].DefaultCellStyle.Format = "dd/MM/yyyy";
            }

            if (dgv_Inscriptions.Columns["LieuTriathlon"] != null)
                dgv_Inscriptions.Columns["LieuTriathlon"].HeaderText = "Lieu";

            dgv_Inscriptions.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void btn_Valider_Click(object sender, EventArgs e)
        {
            if (!ValiderSaisie())
                return;

            try
            {
                if (modeModification)
                {
                    triathlete.Nom = tb_Nom.Text.Trim();
                    triathlete.Prenom = tb_Prenom.Text.Trim();
                    triathlete.Sexe = cb_Sexe.SelectedItem.ToString()[0];
                    triathlete.AdresseRue = tb_AdresseRue.Text.Trim();
                    triathlete.AdresseCP = tb_AdresseCP.Text.Trim();
                    triathlete.AdresseVille = tb_AdresseVille.Text.Trim();
                    triathlete.DateNaissance = dtp_DateNaissance.Value.Date;
                    triathlete.CodeCategorie = (int)cb_Categorie.SelectedValue;

                    int result = TriathleteDAO.ModifierTriathlete(triathlete);

                    if (result > 0)
                    {
                        MessageBox.Show("Triathl�te modifi� avec succ�s !", "Succ�s",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Erreur lors de la modification du triathl�te.", "Erreur",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    Triathlete nouveauTriathlete = new Triathlete(
                        int.Parse(tb_NumLicence.Text),
                        tb_Nom.Text.Trim(),
                        tb_Prenom.Text.Trim(),
                        cb_Sexe.SelectedItem.ToString()[0],
                        tb_AdresseRue.Text.Trim(),
                        tb_AdresseCP.Text.Trim(),
                        tb_AdresseVille.Text.Trim(),
                        dtp_DateNaissance.Value.Date,
                        (int)cb_Categorie.SelectedValue,
                        tb_Login.Text.Trim()
                    );

                    string motDePasseDefaut = "123";
                    string hash = CalculerHash(motDePasseDefaut);

                    int result = TriathleteDAO.AjouterTriathlete(nouveauTriathlete, hash);

                    if (result > 0)
                    {
                        MessageBox.Show("Triathl�te ajout� avec succ�s !\nMot de passe par d�faut : 123", "Succ�s",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Erreur lors de l'ajout du triathl�te.", "Erreur",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message, "Erreur",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValiderSaisie()
        {
            if (!modeModification && string.IsNullOrWhiteSpace(tb_Login.Text))
            {
                MessageBox.Show("Veuillez saisir un login.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tb_Login.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tb_Nom.Text))
            {
                MessageBox.Show("Veuillez saisir un nom.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tb_Nom.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tb_Prenom.Text))
            {
                MessageBox.Show("Veuillez saisir un pr�nom.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tb_Prenom.Focus();
                return false;
            }

            if (cb_Sexe.SelectedItem == null)
            {
                MessageBox.Show("Veuillez s�lectionner un sexe.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cb_Sexe.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tb_AdresseRue.Text))
            {
                MessageBox.Show("Veuillez saisir une adresse.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tb_AdresseRue.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tb_AdresseCP.Text))
            {
                MessageBox.Show("Veuillez saisir un code postal.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tb_AdresseCP.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tb_AdresseVille.Text))
            {
                MessageBox.Show("Veuillez saisir une ville.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tb_AdresseVille.Focus();
                return false;
            }

            if (cb_Categorie.SelectedValue == null)
            {
                MessageBox.Show("Veuillez s�lectionner une cat�gorie.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cb_Categorie.Focus();
                return false;
            }

            return true;
        }

        private void btn_Annuler_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void dgv_Inscriptions_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_NouvelleInscription_Click(object sender, EventArgs e)
        {

        }

        private void btn_ReinitialiserMdp_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Voulez-vous r�initialiser le mot de passe � '123' ?",
                "R�initialisation du mot de passe",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                try
                {
                    string nouveauMdp = "123";
                    string hash = CalculerHash(nouveauMdp);

                    int res = TriathleteDAO.ReinitialiserMotDePasse(triathlete.NumLicence, hash);

                    if (res > 0)
                    {
                        MessageBox.Show("Mot de passe r�initialis� � '123' avec succ�s !", "Succ�s",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Erreur lors de la r�initialisation du mot de passe.", "Erreur",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur : " + ex.Message, "Erreur",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private string CalculerHash(string motDePasse)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(motDePasse));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void btn_Supprimer_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Voulez-vous vraiment supprimer ce triathl�te et toutes ses donn�es associ�es (inscriptions, pr�l�vements, etc.) ?",
                "Confirmation de suppression",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.Yes)
            {
                try
                {
                    TriathleteDAO.SupprimerTriathlete(triathlete.NumLicence);
                    MessageBox.Show("Triathl�te supprim� avec succ�s !", "Succ�s",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de la suppression : " + ex.Message, "Erreur",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
